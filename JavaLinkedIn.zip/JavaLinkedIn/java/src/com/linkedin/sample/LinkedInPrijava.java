package com.linkedin.sample;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.scribe.builder.ServiceBuilder;
import org.scribe.builder.api.LinkedInApi;
import org.scribe.model.OAuthRequest;
import org.scribe.model.Response;
import org.scribe.model.Token;
import org.scribe.model.Verb;
import org.scribe.model.Verifier;
import org.scribe.oauth.OAuthService;

public class LinkedInPrijava {

	private JFrame frmLinkedinPrijava;
	
    private static String API_KEY = "77sleceryuqnlo";
    private static String API_SECRET = "kFHHn8Jn8uV687mY";
    String id, ime, priimek, naslov;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LinkedInPrijava window = new LinkedInPrijava();
					window.frmLinkedinPrijava.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LinkedInPrijava() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmLinkedinPrijava = new JFrame();
		frmLinkedinPrijava.setTitle("LinkedIn Prijava");
		frmLinkedinPrijava.setBounds(100, 100, 850, 450);
		frmLinkedinPrijava.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmLinkedinPrijava.getContentPane().setLayout(null);
			
		final JLabel lblIdUporabnika = new JLabel("ID uporabnika: ");
		lblIdUporabnika.setBounds(222, 13, 598, 16);
		frmLinkedinPrijava.getContentPane().add(lblIdUporabnika);
		
		final JLabel lblImeInPriimek = new JLabel("Ime in priimek uporabnika: ");
		lblImeInPriimek.setBounds(222, 33, 598, 16);
		frmLinkedinPrijava.getContentPane().add(lblImeInPriimek);
		
		final JLabel lblNaslovUporabnika = new JLabel("Naslov uporabnika: ");
		lblNaslovUporabnika.setBounds(222, 53, 598, 16);
		frmLinkedinPrijava.getContentPane().add(lblNaslovUporabnika);
		
		final JLabel lblStatus = new JLabel("Status:");
		lblStatus.setBounds(20, 384, 800, 16);
		frmLinkedinPrijava.getContentPane().add(lblStatus);
		
		final JLabel lblKateroDruabnoOmreje = new JLabel("Katero dru\u017Eabno omre\u017Eje najraje uporabljate?");
		lblKateroDruabnoOmreje.setEnabled(false);
		lblKateroDruabnoOmreje.setBounds(505, 82, 337, 16);
		frmLinkedinPrijava.getContentPane().add(lblKateroDruabnoOmreje);
		
		final JRadioButton rdbtnGoogle = new JRadioButton("Google+");
		rdbtnGoogle.setSelected(true);
		rdbtnGoogle.setEnabled(false);
		rdbtnGoogle.setBounds(474, 111, 127, 25);
		frmLinkedinPrijava.getContentPane().add(rdbtnGoogle);
		
		final JRadioButton rdbtnFacebook = new JRadioButton("Facebook");
		rdbtnFacebook.setEnabled(false);
		rdbtnFacebook.setBounds(474, 141, 127, 25);
		frmLinkedinPrijava.getContentPane().add(rdbtnFacebook);
		
		final JRadioButton rdbtnTwitter = new JRadioButton("Twitter");
		rdbtnTwitter.setEnabled(false);
		rdbtnTwitter.setBounds(474, 171, 127, 25);
		frmLinkedinPrijava.getContentPane().add(rdbtnTwitter);
		
		final JRadioButton rdbtnLinkedin = new JRadioButton("LinkedIn");
		rdbtnLinkedin.setEnabled(false);
		rdbtnLinkedin.setBounds(474, 201, 127, 25);
		frmLinkedinPrijava.getContentPane().add(rdbtnLinkedin);
		
		final JRadioButton rdbtnYahoo = new JRadioButton("Yahoo!");
		rdbtnYahoo.setEnabled(false);
		rdbtnYahoo.setBounds(474, 231, 127, 25);
		frmLinkedinPrijava.getContentPane().add(rdbtnYahoo);
		
		final JRadioButton rdbtnInstagram = new JRadioButton("Instagram");
		rdbtnInstagram.setEnabled(false);
		rdbtnInstagram.setBounds(474, 261, 127, 25);
		frmLinkedinPrijava.getContentPane().add(rdbtnInstagram);
		
		final JRadioButton rdbtnPinterest = new JRadioButton("Pinterest");
		rdbtnPinterest.setEnabled(false);
		rdbtnPinterest.setBounds(474, 291, 127, 25);
		frmLinkedinPrijava.getContentPane().add(rdbtnPinterest);
		
		final JRadioButton rdbtnDrugo = new JRadioButton("Drugo");
		rdbtnDrugo.setEnabled(false);
		rdbtnDrugo.setBounds(474, 321, 127, 25);
		frmLinkedinPrijava.getContentPane().add(rdbtnDrugo);
		
		ButtonGroup group = new ButtonGroup();
        group.add(rdbtnGoogle);
        group.add(rdbtnFacebook);
        group.add(rdbtnTwitter);
        group.add(rdbtnLinkedin);
        group.add(rdbtnYahoo);
        group.add(rdbtnInstagram);
        group.add(rdbtnPinterest);
        group.add(rdbtnDrugo);
        
		final JButton btnNewButton_1 = new JButton("Glasuj");
		btnNewButton_1.setEnabled(false);
		
		btnNewButton_1.addActionListener(new ActionListener() {
			@SuppressWarnings("unchecked")
			public void actionPerformed(ActionEvent arg0) {
				
				try
				{
				Date date = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy-h-mm-ss-S");
				String formattedDate = sdf.format(date);
				SimpleDateFormat sdf2 = new SimpleDateFormat("MM.dd.yyyy h:mm:ss");
				String formattedDate2 = sdf2.format(date);
				
				File dir = new File("C:\\rezultati");
				if (!dir.exists()) {
					dir.mkdir();
				}
				
				File file = new File("C:\\rezultati\\"+formattedDate+".json");
				
				JSONObject obj = new JSONObject();
				obj.put("ID", id);
				obj.put("Ime", ime + " "+ priimek);
				obj.put("Cas", formattedDate2);
				

				if(rdbtnGoogle.isSelected()) 
					obj.put("Izbrano", rdbtnGoogle.getText());
				else if(rdbtnFacebook.isSelected()) 
					obj.put("Izbrano", rdbtnFacebook.getText());
				else if(rdbtnTwitter.isSelected()) 
					obj.put("Izbrano", rdbtnTwitter.getText());
				else if(rdbtnLinkedin.isSelected())	
					obj.put("Izbrano", rdbtnLinkedin.getText());
				else if(rdbtnYahoo.isSelected()) 
					obj.put("Izbrano", rdbtnYahoo.getText());
				else if(rdbtnInstagram.isSelected()) 
					obj.put("Izbrano", rdbtnInstagram.getText());
				else if(rdbtnPinterest.isSelected()) 
					obj.put("Izbrano", rdbtnPinterest.getText());
				else if(rdbtnDrugo.isSelected()) 
					obj.put("Izbrano", rdbtnDrugo.getText());

				obj.put("PrekoAplikacije", "Java LinkedIn Prijava");
				
				FileWriter fw = new FileWriter(file.getAbsoluteFile());
				
				fw.write(obj.toJSONString());
				fw.flush();
				fw.close();

				btnNewButton_1.setEnabled(false);
				lblStatus.setText("Hvala za va� glas! Rezultati glasovanja so objavljeni"
						+ " na spletni strani http://localhost:14373/GlasovanjeRezultati.aspx");
				
				}
				catch (Exception e)
				{
					lblStatus.setText("Zgodila se je napaka pri glasovanju!");
				}
			}
		});
		btnNewButton_1.setBounds(610, 295, 158, 51);
		frmLinkedinPrijava.getContentPane().add(btnNewButton_1);
		
		
		JButton btnPrijava = new JButton("Prijava");
		btnPrijava.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
		        Token accessToken = null;
		        OAuthService service = new ServiceBuilder()
		                                .provider(LinkedInApi.class)
		                                .apiKey(API_KEY)
		                                .apiSecret(API_SECRET)
		                                .build();

		        try{
		            File file = new File("service.dat");

		            if(file.exists()){
		                ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(file));
		                AuthHandler authHandler = (AuthHandler) inputStream.readObject();
		                accessToken = authHandler.getAccessToken();
		            } else {
		            	lblStatus.setText("�eton dostopa ni shranjen zato bomo naredili novega");
		                AuthHandler authHandler = new AuthHandler(service);
		                ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream("service.dat"));
		                outputStream.writeObject(authHandler);
		                outputStream.close();
		                accessToken = authHandler.getAccessToken();
		            }

		        }catch (Exception e){
		        	lblStatus.setText("Zgodila se je napaka: " + e.getClass() + " :: " + e.getMessage());
		        }
		        
		        lblStatus.setText("Pridobivanje podatkov profila:");
		        String url = "http://api.linkedin.com/v1/people/~";
		        OAuthRequest request = new OAuthRequest(Verb.GET, url);
		        request.addHeader("x-li-format", "json");
		        service.signRequest(accessToken, request);
		        Response response = request.send();
		        String text = response.getBody();
		        
		        //parsaj JSON in beri:
		        JSONParser parser = new JSONParser();
		        Object obj = null;
				try {
					obj = parser.parse(text);
					
					lblKateroDruabnoOmreje.setEnabled(true);
					rdbtnGoogle.setEnabled(true);
					rdbtnFacebook.setEnabled(true);
					rdbtnTwitter.setEnabled(true);
					rdbtnLinkedin.setEnabled(true);
					rdbtnYahoo.setEnabled(true);
					rdbtnInstagram.setEnabled(true);
					rdbtnPinterest.setEnabled(true);
					rdbtnDrugo.setEnabled(true);
					btnNewButton_1.setEnabled(true);
					
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				JSONObject jsonObject = (JSONObject) obj;
				id = (String) jsonObject.get("id");				
				lblIdUporabnika.setText("ID uporabnika: "+id);				
				ime = (String) jsonObject.get("firstName");
				priimek = (String) jsonObject.get("lastName");
				lblImeInPriimek.setText("Ime in priimek uporabnika: " +ime+" "+priimek);				
				naslov = (String) jsonObject.get("headline");				
				lblNaslovUporabnika.setText("Naslov uporabnika: "+naslov);
				lblStatus.setText("Podatki uspe�no pridobljeni!");
				

			}
		});
		
		btnPrijava.setBounds(10, 62, 188, 51);
		frmLinkedinPrijava.getContentPane().add(btnPrijava);
		
		JLabel lblAppId = new JLabel("Api Key: " +API_KEY);
		lblAppId.setBounds(10, 13, 380, 16);
		frmLinkedinPrijava.getContentPane().add(lblAppId);
		
		JLabel lblAppSecret = new JLabel("Api Secret: " +API_SECRET);
		lblAppSecret.setBounds(10, 33, 380, 16);
		frmLinkedinPrijava.getContentPane().add(lblAppSecret);
	}
	
	}

class AuthHandler implements Serializable
{
  private static final long serialVersionUID = 1L;
  private Token accessToken = null;

  public AuthHandler(OAuthService serviceProvider)
  {
    Token requestToken = serviceProvider.getRequestToken();
    JTextArea textarea= new JTextArea(serviceProvider.getAuthorizationUrl(requestToken));
    textarea.setEditable(true);
    JOptionPane.showMessageDialog(null, textarea, "Kopiraj povezavo na spletni brskalnik:", JOptionPane.PLAIN_MESSAGE);
    String userInput = JOptionPane.showInputDialog("Vnesi PIN:");
    Verifier verifier = new Verifier(userInput);
    accessToken = serviceProvider.getAccessToken(requestToken, verifier);
  }

  public Token getAccessToken()
  {
    return this.accessToken;
  }

}
