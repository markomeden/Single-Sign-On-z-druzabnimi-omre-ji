import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;

import org.json.simple.JSONObject;

import facebook4j.FacebookException;
import facebook4j.FacebookFactory;
import facebook4j.User;
import facebook4j.auth.AccessToken;

public class FacebookPrijava {

	private JFrame frmFacebookPrijava;

	private static String appId = "913780072029121";
	private static String secret = "27aef73a8f93e2a62801cdc0eb3070d0";
	private static String accessToken = "CAAMZCFACYm8EBAKTOdQ3ZCrKiAejUdCtGH0hZCgxCAvKBzpxuaRCAgufidwLO4TrjGuU50ATaPyBhWx0XFkkbpTseJIKhPwDIkHZCAU9e95tQjjeKlBgZCoP1L1EdfFwyEGfdcEaDyKiFF676iz0cOeLpMrFQuLrr97TScp7gvyZCAIeODjYpNeBD4ZCl5v1H6SZCHMdnKEOvAZDZD";
	private static facebook4j.Facebook facebook = new FacebookFactory().getInstance();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) throws FacebookException {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FacebookPrijava window = new FacebookPrijava();
					window.frmFacebookPrijava.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FacebookPrijava() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmFacebookPrijava = new JFrame();
		frmFacebookPrijava.setTitle("Facebook Prijava");
		frmFacebookPrijava.setBounds(100, 100, 850, 450);
		frmFacebookPrijava.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmFacebookPrijava.getContentPane().setLayout(null);
		
		JLabel lblVrednostetona = new JLabel("Vrednost \u017Eetona:");
		lblVrednostetona.setBounds(10, 63, 209, 26);
		frmFacebookPrijava.getContentPane().add(lblVrednostetona);
		
		JLabel lblIdUporabnika = new JLabel("ID uporabnika:");
		lblIdUporabnika.setBounds(464, 13, 356, 16);
		frmFacebookPrijava.getContentPane().add(lblIdUporabnika);
		
		JLabel lblImeInPriimek = new JLabel("Ime in priimek uporabnika:");
		lblImeInPriimek.setBounds(464, 33, 356, 16);
		frmFacebookPrijava.getContentPane().add(lblImeInPriimek);
		
		JLabel lblEmailUporabnika = new JLabel("Email uporabnika:");
		lblEmailUporabnika.setBounds(464, 53, 356, 16);
		frmFacebookPrijava.getContentPane().add(lblEmailUporabnika);
		
		JEditorPane editorPane_1 = new JEditorPane();
		editorPane_1.setEnabled(false);
		editorPane_1.setBounds(231, 86, 209, 187);
		editorPane_1.setText("Pozdravljen, Facebook!");
		frmFacebookPrijava.getContentPane().add(editorPane_1);
		
		JLabel lblStatus = new JLabel("Status:");
		lblStatus.setBounds(20, 384, 800, 16);
		frmFacebookPrijava.getContentPane().add(lblStatus);

		JLabel lblKateroDruabnoOmreje = new JLabel("Katero dru\u017Eabno omre\u017Eje najraje uporabljate?");
		lblKateroDruabnoOmreje.setEnabled(false);
		lblKateroDruabnoOmreje.setBounds(505, 82, 337, 16);
		frmFacebookPrijava.getContentPane().add(lblKateroDruabnoOmreje);
		
		JRadioButton rdbtnGoogle = new JRadioButton("Google+");
		rdbtnGoogle.setSelected(true);
		rdbtnGoogle.setEnabled(false);
		rdbtnGoogle.setBounds(474, 111, 127, 25);
		frmFacebookPrijava.getContentPane().add(rdbtnGoogle);
		
		JRadioButton rdbtnFacebook = new JRadioButton("Facebook");
		rdbtnFacebook.setEnabled(false);
		rdbtnFacebook.setBounds(474, 141, 127, 25);
		frmFacebookPrijava.getContentPane().add(rdbtnFacebook);
		
		JRadioButton rdbtnTwitter = new JRadioButton("Twitter");
		rdbtnTwitter.setEnabled(false);
		rdbtnTwitter.setBounds(474, 171, 127, 25);
		frmFacebookPrijava.getContentPane().add(rdbtnTwitter);
		
		JRadioButton rdbtnLinkedin = new JRadioButton("LinkedIn");
		rdbtnLinkedin.setEnabled(false);
		rdbtnLinkedin.setBounds(474, 201, 127, 25);
		frmFacebookPrijava.getContentPane().add(rdbtnLinkedin);
		
		JRadioButton rdbtnYahoo = new JRadioButton("Yahoo!");
		rdbtnYahoo.setEnabled(false);
		rdbtnYahoo.setBounds(474, 231, 127, 25);
		frmFacebookPrijava.getContentPane().add(rdbtnYahoo);
		
		JRadioButton rdbtnInstagram = new JRadioButton("Instagram");
		rdbtnInstagram.setEnabled(false);
		rdbtnInstagram.setBounds(474, 261, 127, 25);
		frmFacebookPrijava.getContentPane().add(rdbtnInstagram);
		
		JRadioButton rdbtnPinterest = new JRadioButton("Pinterest");
		rdbtnPinterest.setEnabled(false);
		rdbtnPinterest.setBounds(474, 291, 127, 25);
		frmFacebookPrijava.getContentPane().add(rdbtnPinterest);
		
		JRadioButton rdbtnDrugo = new JRadioButton("Drugo");
		rdbtnDrugo.setEnabled(false);
		rdbtnDrugo.setBounds(474, 321, 127, 25);
		frmFacebookPrijava.getContentPane().add(rdbtnDrugo);
		
		ButtonGroup group = new ButtonGroup();
        group.add(rdbtnGoogle);
        group.add(rdbtnFacebook);
        group.add(rdbtnTwitter);
        group.add(rdbtnLinkedin);
        group.add(rdbtnYahoo);
        group.add(rdbtnInstagram);
        group.add(rdbtnPinterest);
        group.add(rdbtnDrugo);
        
		JButton btnNewButton_1 = new JButton("Glasuj");
		
		JButton btnNewButton = new JButton("Poslji sporocilo");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					facebook.postStatusMessage(editorPane_1.getText());
					lblStatus.setText("Status: Sporo�ilo je bilo uspe�no poslano.");
				} catch (FacebookException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					lblStatus.setText("Status: Napaka pri po�iljanju sporo�ila!");
				}
				
			}
		});
		btnNewButton.setEnabled(false);
		btnNewButton.setBounds(241, 286, 188, 51);

		frmFacebookPrijava.getContentPane().add(btnNewButton);

		
		
		JButton btnPrijava = new JButton("Prijava");
		btnPrijava.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				facebook.setOAuthAppId(appId, secret);
				facebook.setOAuthPermissions("publish_actions,manage_pages,email");
				facebook.setOAuthAccessToken(new AccessToken(accessToken, null));

				User user;
				try {
					user = facebook.getMe();
					
					lblIdUporabnika.setText("ID uporabnika: "+user.getId());
					lblImeInPriimek.setText("Ime in priimek uporabnika: "+user.getName());
					lblEmailUporabnika.setText("Email uporabnika: "+user.getEmail());
					editorPane_1.setEnabled(true);
					btnNewButton.setEnabled(true);
					lblStatus.setText("Status: Prijava je bila uspe�na.");
					
					lblKateroDruabnoOmreje.setEnabled(true);
					rdbtnGoogle.setEnabled(true);
					rdbtnFacebook.setEnabled(true);
					rdbtnTwitter.setEnabled(true);
					rdbtnLinkedin.setEnabled(true);
					rdbtnYahoo.setEnabled(true);
					rdbtnInstagram.setEnabled(true);
					rdbtnPinterest.setEnabled(true);
					rdbtnDrugo.setEnabled(true);
					btnNewButton_1.setEnabled(true);
					
				} catch (FacebookException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					lblStatus.setText("Status: Prijava ni bila uspe�na. �eton ni pravi!");
				}

			}
		});
		btnPrijava.setBounds(20, 286, 188, 51);
		frmFacebookPrijava.getContentPane().add(btnPrijava);
		
		JLabel lblAppId = new JLabel("Facebook App ID: " +appId);
		lblAppId.setBounds(10, 13, 380, 16);
		frmFacebookPrijava.getContentPane().add(lblAppId);
		
		JLabel lblAppSecret = new JLabel("Facebook App Secret: " +secret);
		lblAppSecret.setBounds(10, 31, 380, 16);
		frmFacebookPrijava.getContentPane().add(lblAppSecret);
		
		JEditorPane editorPane = new JEditorPane();
		editorPane.setBounds(10, 86, 209, 187);
		editorPane.setText(accessToken);
		frmFacebookPrijava.getContentPane().add(editorPane);
		
		btnNewButton_1.setEnabled(false);
		btnNewButton_1.addActionListener(new ActionListener() {
			@SuppressWarnings("unchecked")
			public void actionPerformed(ActionEvent arg0) {
				
				try
				{
				Date date = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy-h-mm-ss-S");
				String formattedDate = sdf.format(date);
				SimpleDateFormat sdf2 = new SimpleDateFormat("MM.dd.yyyy h:mm:ss");
				String formattedDate2 = sdf2.format(date);
				
				File dir = new File("C:\\rezultati");
				if (!dir.exists()) {
					dir.mkdir();
				}
				
				File file = new File("C:\\rezultati\\"+formattedDate+".json");

				User user = facebook.getMe();
				
				JSONObject obj = new JSONObject();
				obj.put("ID", user.getId());
				obj.put("Ime", user.getName());
				obj.put("Cas", formattedDate2);
				

				if(rdbtnGoogle.isSelected()) 
					obj.put("Izbrano", rdbtnGoogle.getText());
				else if(rdbtnFacebook.isSelected()) 
					obj.put("Izbrano", rdbtnFacebook.getText());
				else if(rdbtnTwitter.isSelected()) 
					obj.put("Izbrano", rdbtnTwitter.getText());
				else if(rdbtnLinkedin.isSelected())	
					obj.put("Izbrano", rdbtnLinkedin.getText());
				else if(rdbtnYahoo.isSelected()) 
					obj.put("Izbrano", rdbtnYahoo.getText());
				else if(rdbtnInstagram.isSelected()) 
					obj.put("Izbrano", rdbtnInstagram.getText());
				else if(rdbtnPinterest.isSelected()) 
					obj.put("Izbrano", rdbtnPinterest.getText());
				else if(rdbtnDrugo.isSelected()) 
					obj.put("Izbrano", rdbtnDrugo.getText());

				obj.put("PrekoAplikacije", "Java Facebook Prijava");
				
				FileWriter fw = new FileWriter(file.getAbsoluteFile());
				
				fw.write(obj.toJSONString());
				fw.flush();
				fw.close();

				btnNewButton_1.setEnabled(false);
				lblStatus.setText("Hvala za va� glas! Rezultati glasovanja so objavljeni"
						+ " na spletni strani http://localhost:14373/GlasovanjeRezultati.aspx");
				
				}
				catch (Exception e)
				{
					lblStatus.setText("Zgodila se je napaka pri glasovanju!");
				}
			}
		});
		btnNewButton_1.setBounds(610, 295, 158, 51);
		frmFacebookPrijava.getContentPane().add(btnNewButton_1);
		


	}
}
