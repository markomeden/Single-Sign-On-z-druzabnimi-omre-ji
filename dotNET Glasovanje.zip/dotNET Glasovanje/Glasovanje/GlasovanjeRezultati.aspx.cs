﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;
using System.IO;

namespace Glasovanje
{

    class Uporabnik
    {
        public String id { get; set; }
        public String ime { get; set; }
        public String cas { get; set; }
        public String izbrano { get; set; }
        public String prekoAplikacije { get; set; }
    }

    public partial class Glasovanje : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int[] steviloGlasov = new int[8];

            try
            {
                foreach (string file in Directory.EnumerateFiles("C:\\rezultati", "*.json"))
                {
                    string contents = File.ReadAllText(file);
                    Uporabnik u = JsonConvert.DeserializeObject<Uporabnik>(contents);
                    Label1.Text += string.Format("{0}: Oseba <b>{1}</b> je glasovala za " +
                        "<b>{2}</b> preko aplikacije \"<b>{3}</b>\" .<br />",
                        u.cas, u.ime, u.izbrano, u.prekoAplikacije);

                    if (u.izbrano.Equals("Google+"))
                        steviloGlasov[0]++;
                    else if (u.izbrano.Equals("Facebook"))
                        steviloGlasov[1]++;
                    else if (u.izbrano.Equals("Twitter"))
                        steviloGlasov[2]++;
                    else if (u.izbrano.Equals("LinkedIn"))
                        steviloGlasov[3]++;
                    else if (u.izbrano.Equals("Yahoo!"))
                        steviloGlasov[4]++;
                    else if (u.izbrano.Equals("Instagram"))
                        steviloGlasov[5]++;
                    else if (u.izbrano.Equals("Pinterest"))
                        steviloGlasov[6]++;
                    else if (u.izbrano.Equals("Drugo"))
                        steviloGlasov[7]++;
                }


                Label2.Text += string.Format("<br /> Google+: {0} <br /> Facebook: {1} " +
                "<br /> Twitter: {2} <br /> LinkedIn: {3} <br /> Yahoo!: {4} <br /> " +
                " Instagram: {5} <br /> Pinterest: {6} <br /> Drugo: {7} <br />",
                steviloGlasov[0], steviloGlasov[1], steviloGlasov[2], steviloGlasov[3],
                steviloGlasov[4], steviloGlasov[5], steviloGlasov[6], steviloGlasov[7]);
            }
            catch (Exception ex)
            {

            }
        }

    }
}