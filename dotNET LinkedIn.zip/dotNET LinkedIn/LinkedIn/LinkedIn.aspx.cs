﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ASPSnippets.LinkedInAPI;
using System.Data;
using System.IO;
using Newtonsoft.Json;

namespace LinkedIn
{
    public partial class LinkedIn : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LinkedInConnect.APIKey = "77sleceryuqnlo";
            LinkedInConnect.APISecret = "kFHHn8Jn8uV687mY";
            LinkedInConnect.RedirectUrl = Request.Url.AbsoluteUri.Split('?')[0];

            if (LinkedInConnect.IsAuthorized)
            {
                try
                {
                    DataSet ds = LinkedInConnect.Fetch();
                    ID.Text = ds.Tables["person"].Rows[0]["id"].ToString();
                    Ime.Text = ds.Tables["person"].Rows[0]["first-name"].ToString();
                    Priimek.Text = ds.Tables["person"].Rows[0]["last-name"].ToString();
                    Email.Text = ds.Tables["person"].Rows[0]["email-address"].ToString();
                    Naslov.Text = ds.Tables["person"].Rows[0]["headline"].ToString();
                    prikaziGumbe();
                }
                catch (Exception ex)
                {

                }
            }
        }

        protected void Avtoriziraj(object sender, EventArgs e)
        {
            LinkedInConnect.Authorize();
        }

        public void prikaziGumbe()
        {

            Label3.Visible = true;
            Label4.Visible = true;
            RadioButtonList1.Visible = true;
            Button2.Visible = true;
        }

        public void skrijGumbe()
        {

            Label3.Visible = false;
            Label4.Visible = false;
            RadioButtonList1.Visible = true;
            Button2.Visible = false;
        }

        public class Uporabnik
        {
            public String ID { get; set; }
            public String Ime { get; set; }
            public String Cas { get; set; }
            public String Izbrano { get; set; }
            public String PrekoAplikacije { get; set; }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                String sdf = DateTime.Now.ToString("MM-dd-yyyy-h-mm-ss-fff");
                String sdf2 = DateTime.Now.ToString("MM.dd.yyyy h:mm:ss");

                string pathString = @"c:\rezultati";
                if (!System.IO.Directory.Exists(pathString))
                    System.IO.Directory.CreateDirectory(pathString);

                string fileName = "c:\\rezultati\\" + sdf + ".json";

                Uporabnik u = new Uporabnik();
                u.ID = ID.Text;
                u.Ime = Ime.Text + " " + Priimek.Text;
                u.Cas = sdf2;
                u.Izbrano = RadioButtonList1.SelectedValue.ToString();
                u.PrekoAplikacije = ".NET LinkedIn Prijava";

                StreamWriter sw = new StreamWriter(fileName);
                sw.Write(JsonConvert.SerializeObject(u));
                sw.Flush();
                sw.Close();

                Button2.Enabled = false;
                Label3.Text = "Hvala za vaš glas! Rezultati glasovanja so" +
                    "objavljeni spletni strani http://localhost:14373/GlasovanjeRezultati.aspx";

            }
            catch (Exception ex)
            {
                Label3.Text = "Zgodila se je napaka pri glasovanju!";
            }
        }

    }
}