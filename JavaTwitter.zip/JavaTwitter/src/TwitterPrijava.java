import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;

import org.json.simple.JSONObject;

import twitter4j.Status;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;

public class TwitterPrijava {

	JFrame frame;
		
	private static String consumerKey = "";
	private static String consumerSecret = "";
	private static String accessToken = "";
	private static String acccessTokenSecret = "";
	private static ConfigurationBuilder cb = new ConfigurationBuilder();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TwitterPrijava window = new TwitterPrijava();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @wbp.parser.entryPoint
	 */
	public TwitterPrijava() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Twitter Prijava");
		frame.setBounds(100, 100, 850, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
			
		JLabel lblIdUporabnika = new JLabel("ID uporabnika: ");
		lblIdUporabnika.setBounds(464, 13, 356, 16);
		frame.getContentPane().add(lblIdUporabnika);
		
		JLabel lblImeInPriimek = new JLabel("Ime in priimek uporabnika: ");
		lblImeInPriimek.setBounds(464, 33, 356, 16);
		frame.getContentPane().add(lblImeInPriimek);
		
		JLabel lblEmailUporabnika = new JLabel("Email uporabnika: ");
		lblEmailUporabnika.setBounds(464, 53, 356, 16);
		frame.getContentPane().add(lblEmailUporabnika);
		
		JEditorPane editorPanel = new JEditorPane();
		editorPanel.setEnabled(false);
		editorPanel.setBounds(233, 120, 209, 187);
		editorPanel.setText("Pozdravljen, Twitter!");
		frame.getContentPane().add(editorPanel);
		
		JLabel lblStatus = new JLabel("Status:");
		lblStatus.setBounds(20, 384, 800, 16);
		frame.getContentPane().add(lblStatus);
		
		JLabel lblKateroDruabnoOmreje = new JLabel("Katero dru\u017Eabno omre\u017Eje najraje uporabljate?");
		lblKateroDruabnoOmreje.setEnabled(false);
		lblKateroDruabnoOmreje.setBounds(505, 82, 337, 16);
		frame.getContentPane().add(lblKateroDruabnoOmreje);
		
		JRadioButton rdbtnGoogle = new JRadioButton("Google+");
		rdbtnGoogle.setSelected(true);
		rdbtnGoogle.setEnabled(false);
		rdbtnGoogle.setBounds(474, 111, 127, 25);
		frame.getContentPane().add(rdbtnGoogle);
		
		JRadioButton rdbtnFacebook = new JRadioButton("Facebook");
		rdbtnFacebook.setEnabled(false);
		rdbtnFacebook.setBounds(474, 141, 127, 25);
		frame.getContentPane().add(rdbtnFacebook);
		
		JRadioButton rdbtnTwitter = new JRadioButton("Twitter");
		rdbtnTwitter.setEnabled(false);
		rdbtnTwitter.setBounds(474, 171, 127, 25);
		frame.getContentPane().add(rdbtnTwitter);
		
		JRadioButton rdbtnLinkedin = new JRadioButton("LinkedIn");
		rdbtnLinkedin.setEnabled(false);
		rdbtnLinkedin.setBounds(474, 201, 127, 25);
		frame.getContentPane().add(rdbtnLinkedin);
		
		JRadioButton rdbtnYahoo = new JRadioButton("Yahoo!");
		rdbtnYahoo.setEnabled(false);
		rdbtnYahoo.setBounds(474, 231, 127, 25);
		frame.getContentPane().add(rdbtnYahoo);
		
		JRadioButton rdbtnInstagram = new JRadioButton("Instagram");
		rdbtnInstagram.setEnabled(false);
		rdbtnInstagram.setBounds(474, 261, 127, 25);
		frame.getContentPane().add(rdbtnInstagram);
		
		JRadioButton rdbtnPinterest = new JRadioButton("Pinterest");
		rdbtnPinterest.setEnabled(false);
		rdbtnPinterest.setBounds(474, 291, 127, 25);
		frame.getContentPane().add(rdbtnPinterest);
		
		JRadioButton rdbtnDrugo = new JRadioButton("Drugo");
		rdbtnDrugo.setEnabled(false);
		rdbtnDrugo.setBounds(474, 321, 127, 25);
		frame.getContentPane().add(rdbtnDrugo);
		
		ButtonGroup group = new ButtonGroup();
        group.add(rdbtnGoogle);
        group.add(rdbtnFacebook);
        group.add(rdbtnTwitter);
        group.add(rdbtnLinkedin);
        group.add(rdbtnYahoo);
        group.add(rdbtnInstagram);
        group.add(rdbtnPinterest);
        group.add(rdbtnDrugo);
        
		JButton btnNewButton_1 = new JButton("Glasuj");
		btnNewButton_1.setEnabled(false);
		
		btnNewButton_1.addActionListener(new ActionListener() {
			@SuppressWarnings("unchecked")
			public void actionPerformed(ActionEvent arg0) {
				
				try
				{
				Date date = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy-h-mm-ss-S");
				String formattedDate = sdf.format(date);
				SimpleDateFormat sdf2 = new SimpleDateFormat("MM.dd.yyyy h:mm:ss");
				String formattedDate2 = sdf2.format(date);
				
				File dir = new File("C:\\rezultati");
				if (!dir.exists()) {
					dir.mkdir();
				}
				
				File file = new File("C:\\rezultati\\"+formattedDate+".json");

				twitter4j.Twitter twitter = new TwitterFactory(cb.build()).getInstance(); 
				twitter4j.User user = twitter.verifyCredentials();
				
				JSONObject obj = new JSONObject();
				obj.put("ID", user.getId());
				obj.put("Ime", user.getName());
				obj.put("Cas", formattedDate2);
				
				if(rdbtnGoogle.isSelected()) 
					obj.put("Izbrano", rdbtnGoogle.getText());
				else if(rdbtnFacebook.isSelected()) 
					obj.put("Izbrano", rdbtnFacebook.getText());
				else if(rdbtnTwitter.isSelected()) 
					obj.put("Izbrano", rdbtnTwitter.getText());
				else if(rdbtnLinkedin.isSelected())	
					obj.put("Izbrano", rdbtnLinkedin.getText());
				else if(rdbtnYahoo.isSelected()) 
					obj.put("Izbrano", rdbtnYahoo.getText());
				else if(rdbtnInstagram.isSelected()) 
					obj.put("Izbrano", rdbtnInstagram.getText());
				else if(rdbtnPinterest.isSelected()) 
					obj.put("Izbrano", rdbtnPinterest.getText());
				else if(rdbtnDrugo.isSelected()) 
					obj.put("Izbrano", rdbtnDrugo.getText());

				obj.put("PrekoAplikacije", "Java Twitter Prijava");
				
				FileWriter fw = new FileWriter(file.getAbsoluteFile());
				
				fw.write(obj.toJSONString());
				fw.flush();
				fw.close();

				btnNewButton_1.setEnabled(false);
				lblStatus.setText("Hvala za va� glas! Rezultati glasovanja so objavljeni"
						+ " na spletni strani http://localhost:14373/GlasovanjeRezultati.aspx");
				
				}
				catch (Exception e)
				{
					lblStatus.setText("Zgodila se je napaka pri glasovanju!");
				}
			}
		});
		btnNewButton_1.setBounds(610, 295, 158, 51);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Po�lji sporo�ilo");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					twitter4j.Twitter twitter = new TwitterFactory(cb.build()).getInstance(); 
					Status status = twitter.updateStatus(editorPanel.getText());
					lblStatus.setText("Status: Sporo�ilo je bilo uspe�no poslano.");
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					lblStatus.setText("Status: Napaka pri po�iljanju sporo�ila!");
				}
				
			}
		});
		btnNewButton.setEnabled(false);
		btnNewButton.setBounds(241, 320, 188, 51);

		frame.getContentPane().add(btnNewButton);


		JButton btnPrijava = new JButton("Prijava");
		btnPrijava.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			    
				cb.setDebugEnabled(true)
		         .setOAuthConsumerKey(consumerKey)
		         .setOAuthConsumerSecret(consumerSecret)
		         .setOAuthAccessToken(accessToken)
		         .setOAuthAccessTokenSecret(acccessTokenSecret);
				twitter4j.Twitter twitter = new TwitterFactory(cb.build()).getInstance();  
				
				try {
				    
				    twitter4j.User user = twitter.verifyCredentials();
					
					lblIdUporabnika.setText("ID uporabnika: "+user.getId());
					lblImeInPriimek.setText("Ime in priimek uporabnika: "+user.getName());
					lblEmailUporabnika.setText("Timezone uporabnika: "+user.getTimeZone());
					editorPanel.setEnabled(true);
					btnNewButton.setEnabled(true);
					lblStatus.setText("Status: Prijava je bila uspe�na.");
					
					lblKateroDruabnoOmreje.setEnabled(true);
					rdbtnGoogle.setEnabled(true);
					rdbtnFacebook.setEnabled(true);
					rdbtnTwitter.setEnabled(true);
					rdbtnLinkedin.setEnabled(true);
					rdbtnYahoo.setEnabled(true);
					rdbtnInstagram.setEnabled(true);
					rdbtnPinterest.setEnabled(true);
					rdbtnDrugo.setEnabled(true);
					btnNewButton_1.setEnabled(true);
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					lblStatus.setText("Status: Prijava ni bila uspe�na. �eton ni pravi!");
				}

			}
		});
		btnPrijava.setBounds(20, 320, 188, 51);
		frame.getContentPane().add(btnPrijava);
		
		JLabel lblAppId = new JLabel("Consumer Key: " +consumerKey);
		lblAppId.setBounds(10, 13, 380, 16);
		frame.getContentPane().add(lblAppId);
		
		JLabel lblAppSecret = new JLabel("Consumer Secret: " +consumerSecret);
		lblAppSecret.setBounds(10, 33, 380, 16);
		frame.getContentPane().add(lblAppSecret);
		
		JLabel lblAccessTokenSecret = new JLabel("Access Token Secret:" +acccessTokenSecret);
		lblAccessTokenSecret.setBounds(10, 73, 380, 16);
		frame.getContentPane().add(lblAccessTokenSecret);
		
		JLabel lblVrednostetona = new JLabel("Access Token: " +accessToken);
		lblVrednostetona.setBounds(10, 53, 380, 16);
		frame.getContentPane().add(lblVrednostetona);

	}
}