﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Facebook;
using System.Web.Security;
using System.IO;
using Newtonsoft.Json;


namespace Facebook3
{
    public partial class Facebook : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            {
                // Prvo poglej ali je uporabnik že prijavljen
                if (Session["AccessToken"] != null)
                {
                    Label2.Text = Session["AccessToken"].ToString();

                    // Pridobi obstoječe uporabnikove informacije ali pa naredi nov FacebookClient
                    var facebookClient = new FacebookClient(Session["AccessToken"].ToString());

                    dynamic me = facebookClient.Get("me?fields=name,email");
                    Label1.Text = "" + me.id + "<br>" + me.name + "<br>" + me.email;
                    Label2.Text = Session["AccessToken"].ToString();

                    Button1.Text = "Odjava";

                    prikaziGumbe();
                }

                // Ta koda se izvede ko dobimo odgovor s strani Facebooka
                else if (Request.QueryString["code"] != null)
                {
                    string accessCode = Request.QueryString["code"].ToString();
                    var facebookClient = new FacebookClient();

                    dynamic result = facebookClient.Post("oauth/access_token", new
                    {
                        client_id = "913780072029121",
                        client_secret = "27aef73a8f93e2a62801cdc0eb3070d0",
                        redirect_uri = "http://localhost:3195/Facebook.aspx",
                        code = accessCode
                    });

                    var accessToken = result.access_token;
                    var expires = result.expires;

                    // Shrani žeton dostopa v sejo
                    Session["AccessToken"] = accessToken;

                    // posodobi facebook odjemalca z žetonom dostopa
                    facebookClient.AccessToken = accessToken;

                    // Uporabi Graph API za informacije
                    dynamic me = facebookClient.Get("me?fields=name,email");

                    // posodobi label polje s podatki, ki jih pridobimo iz objekta "me"
                    Label1.Text = "" + me.id + "<br>" + me.name + "<br>" + me.email;
                    Label2.Text = Session["AccessToken"].ToString();

                    try
                    {
                        facebookClient.Post("/me/feed", new { message = "Facebook SDK .NET testni post" });
                    }
                    catch (Exception ex)
                    {

                    }

                    Button1.Text = "Odjava";
                    FormsAuthentication.SetAuthCookie(me.email, false);

                    prikaziGumbe();
                }

                    //Razreši situacijo, kjer si uporabnik premisli s prijavo
                else if (Request.QueryString["error"] != null)
                {
                    string error = Request.QueryString["error"];
                    string errorReason = Request.QueryString["error_reason"];
                    string errorDescription = Request.QueryString["error_description"];
                }

                else
                {
                    //Uporabnik ni povezan
                }
            }
        }

        public void prikaziGumbe()
        {
            Label2.Visible = true;
            Label3.Visible = true;
            Label4.Visible = true;
            RadioButtonList1.Visible = true;
            Button2.Visible = true;
        }

        public void skrijGumbe()
        {
            Label2.Visible = false;
            Label3.Visible = false;
            Label4.Visible = false;
            RadioButtonList1.Visible = true;
            Button2.Visible = false;
        }
            

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (Button1.Text == "Odjava")
            {
                odjava();
                skrijGumbe();
            }
            else
            {
                var facebookClient = new FacebookClient();
                var loginUrl = facebookClient.GetLoginUrl(new
                {

                    client_id = "913780072029121",
                    redirect_uri = "http://localhost:3195/Facebook.aspx",
                    response_type = "code",
                    scope = "publish_actions,manage_pages,email" // Dovoljenja
                });
                Response.Redirect(loginUrl.AbsoluteUri);
                prikaziGumbe();

            }
        }

        private void odjava()
        {
            var facebookClient = new FacebookClient();
            var logoutUrl = facebookClient.GetLogoutUrl(new
            {
                access_token = Session["AccessToken"],
                next = "http://localhost:3195/Facebook.aspx"

            });

            // Ko se uporabnik odjavi, odstrani žeton
            Session.Remove("AccessToken");
            Response.Redirect(logoutUrl.AbsoluteUri);
        }

        public class Uporabnik {
            public String ID {get;set;}
            public String Ime {get;set;}
            public String Cas {get;set;}
            public String Izbrano {get;set;}
            public String PrekoAplikacije { get; set; }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            try 
            {
            String sdf = DateTime.Now.ToString("MM-dd-yyyy-h-mm-ss-fff");
            String sdf2 = DateTime.Now.ToString("MM.dd.yyyy h:mm:ss");

	        string pathString = @"c:\rezultati";
            if(!System.IO.Directory.Exists(pathString))
                System.IO.Directory.CreateDirectory(pathString);
				
            string fileName = "c:\\rezultati\\" +sdf+".json";

            var facebookClient = new FacebookClient(Session["AccessToken"].ToString());
            dynamic me = facebookClient.Get("me?fields=name,email");

            Uporabnik u = new Uporabnik();
            u.ID = me.id;
            u.Ime = me.name;
            u.Cas = sdf2;
            u.Izbrano = RadioButtonList1.SelectedValue.ToString();
            u.PrekoAplikacije = ".NET Facebook Prijava";

            StreamWriter sw = new StreamWriter(fileName);
            sw.Write(JsonConvert.SerializeObject(u));
            sw.Flush();
            sw.Close();

		    Button2.Enabled = false;
            Label3.Text = "Hvala za vaš glas! Rezultati glasovanja so" +
                "objavljeni spletni strani http://localhost:14373/GlasovanjeRezultati.aspx";
				
		    }
		    catch (Exception ex)
			{
				Label3.Text = "Zgodila se je napaka pri glasovanju!";
			}
			}
        }

    }
